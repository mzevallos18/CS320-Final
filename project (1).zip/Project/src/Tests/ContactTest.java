package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import Contact.Contact;

public class ContactTest {

    // Test for successful creation of a contact
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("12345", "Mario", "Zevallos", "1234567890", "Madison, WI");
        // Verify all fields are correctly set
        assertEquals("12345", contact.getContactId());
        assertEquals("Mario", contact.getFirstName());
        assertEquals("Zevallos", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("Madison, WI", contact.getAddress());
    }

    // Test for invalid contact ID
    @Test
    public void testInvalidContactId() {
        // Check for null contact ID
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Mario", "Zevallos", "1234567890", "Madison, WI");
        });
        // Check for contact ID exceeding 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Mario", "Zevallos", "1234567890", "Madison, WI");
        });
    }

    // Test for invalid first name
    @Test
    public void testInvalidFirstName() {
        // Check for null first name
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Zevallos", "1234567890", "Madison, WI");
        });
        // Check for first name exceeding 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "MarioMarioooo", "Zevallos", "1234567890", "Madison, WI");
        });
    }

    // Test for invalid last name
    @Test
    public void testInvalidLastName() {
        // Check for null last name
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Mario", null, "1234567890", "Madison, WI");
        });
        // Check for last name exceeding 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Mario", "Zevallossss", "1234567890", "Madison, WI");
        });
    }

    // Test for invalid phone number
    @Test
    public void testInvalidPhoneNumber() {
        // Check for null phone number
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Mario", "Zevallos", null, "Madison, WI");
        });
        // Check for phone number less than 10 digits
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Mario", "Zevallos", "123456789", "Madison, WI");
        });
        // Check for phone number more than 10 digits
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Mario", "Zevallos", "12345678901", "Madison, WI");
        });
    }

    // Test for invalid address
    @Test
    public void testInvalidAddress() {
        // Check for null address
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Mario", "Zevallos", "1234567890", null);
        });
        // Check for address exceeding 30 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Mario", "Zevallos", "1234567890", "123 Tree Lane, Madison, WI, USA");
        });
    }
}
