package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import Task.TaskService;

public class TaskServiceTest {

    // Test for adding a task successfully
    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        service.addTask("New Task", "This is a test description.");

        // Check that a task was added
        assertEquals(1, service.getAllTasks().size());
    }

    // Test adding multiple unique tasks
    @Test
    public void testTasks() {
        TaskService service = new TaskService();
        service.addTask("Task One", "Description One.");
        service.addTask("Task Two", "Description Two.");

        // Verify both tasks exist
        assertEquals(2, service.getAllTasks().size());
    }

    // Test deleting a task successfully
    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        service.addTask("Task to Delete", "Delete me.");

        String taskId = service.getAllTasks().keySet().iterator().next();
        service.deleteTask(taskId);

        // Verify task is removed
        assertFalse(service.getAllTasks().containsKey(taskId));
    }

    // Test deleting a non-existent task
    @Test
    public void testDeleteNonExistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("99999");
        });
    }

    // Test updating task name successfully
    @Test
    public void testUpdateTaskName() {
        TaskService service = new TaskService();
        service.addTask("Initial Task", "Initial Description.");

        String taskId = service.getAllTasks().keySet().iterator().next();
        service.updateTaskName(taskId, "Updated Task Name");

        assertEquals("Updated Task Name", service.getTask(taskId).getName());
    }

    // Test updating task description successfully
    @Test
    public void testUpdateTaskDescription() {
        TaskService service = new TaskService();
        service.addTask("Task Name", "Initial Description.");

        String taskId = service.getAllTasks().keySet().iterator().next();
        service.updateDescription(taskId, "Updated Description");

        assertEquals("Updated Description", service.getTask(taskId).getDescription());
    }

    // Test updating name of non-existent task
    @Test
    public void testUpdateNonExistentTaskName() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("12345", "New Name");
        });
    }

    // Test updating description of non-existent task
    @Test
    public void testUpdateNonExistentTaskDescription() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("12345", "New Description");
        });
    }
}
