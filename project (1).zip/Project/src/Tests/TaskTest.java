package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import Task.Task;

public class TaskTest {

    // Test successful creation of a valid task
    @Test
    public void testTaskCreation() {
        Task task = new Task("12345", "Test Task", "This is a valid task description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a valid task description.", task.getDescription());
    }

    // Test invalid task ID
    @Test
    public void testTaskInvalidID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    // Test invalid task name
    @Test
    public void testTaskInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "aaaaaaaaaaaaaaaaaaaaaaaa", "Description");
        });
    }

    // Test invalid task description
    @Test
    public void testTaskInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.");
        });
    }

    // Test updating task name successfully
    @Test
    public void testUpdateTaskName() {
        Task task = new Task("12345", "Old Name", "Description");
        task.setName("New Task Name");
        assertEquals("New Task Name", task.getName());
    }

    // Test updating task description successfully
    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("12345", "Task Name", "Old Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    // Test setting invalid name
    @Test
    public void testSetInvalidTaskName() {
        Task task = new Task("12345", "Name", "Description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        });
    }

    // Test setting invalid description
    @Test
    public void testSetInvalidTaskDescription() {
        Task task = new Task("12345", "Name", "Description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        });
    }
}
