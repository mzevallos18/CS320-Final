package Tests;

import Appointment.Appointment;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        // Create a future date for a valid appointment
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date futureDate = calendar.getTime();
        
        // Verify appointment creation with valid data
        Appointment appointment = new Appointment("1234567890", futureDate, "Valid appointment");
        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Valid appointment", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        // Create a valid future date
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date futureDate = calendar.getTime();
        
        // Verify invalid ID cases (null and too long)
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Valid description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Valid description"));
    }

    @Test
    public void testInvalidAppointmentDate() {
        // Create a past date (invalid case)
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        Date pastDate = calendar.getTime();

        // Verify past dates are not allowed
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", pastDate, "Valid description"));
    }

    @Test
    public void testInvalidDescription() {
        // Create a valid future date
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date futureDate = calendar.getTime();

        // Verify null descriptions are not allowed
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, null));
    }
}
