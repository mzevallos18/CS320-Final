package Tests;

import Appointment.Appointment;
import Appointment.AppointmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;
    private Appointment appointment;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        appointment = new Appointment("12345", futureDate, "Check-up appointment");
    }

    @Test
    public void testAddAppointment() {
        appointmentService.addAppointment(appointment);
        assertEquals(appointment, appointmentService.getAppointment("12345"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        appointmentService.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment));
    }

    @Test
    public void testDeleteAppointment() {
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("12345");
        assertNull(appointmentService.getAppointment("12345"));
    }

    @Test
    public void testDeleteNonExistingAppointment() {
        assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("99999"));
    }
}
