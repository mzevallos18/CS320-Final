package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Contact.Contact;
import Contact.ContactService;

public class ContactServiceTest {

    // Test for adding a contact
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Mario", "Zevallos", "1234567890", "Madison, WI");
        service.addContact(contact);

        // Verify the contact is successfully added
        assertEquals(contact, service.getContact("12345"));
    }

    // Test for adding a duplicate contact
    @Test
    public void testAddDuplicateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Mario", "Zevallos", "1234567890", "Madison, WI");
        service.addContact(contact);

        // Verify adding a contact with the same ID throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact);
        });
    }

    // Test for deleting a contact
    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Mario", "Zevallos", "1234567890", "Madison, WI");
        service.addContact(contact);

        // Delete the contact
        service.deleteContact("12345");

        // Verify the contact is removed
        assertNull(service.getContact("12345"));
    }

    // Test for updating a contact's fields
    @Test
    public void testUpdateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Mario", "Zevallos", "1234567890", "Madison, WI");
        service.addContact(contact);

        // Update the first name and address of the contact
        service.updateContact("12345", "Mario", null, null, "123 Tree Lane");

        // Verify the updated fields
        assertEquals("Mario", service.getContact("12345").getFirstName());
        assertEquals("123 Tree Lane", service.getContact("12345").getAddress());
    }
}
