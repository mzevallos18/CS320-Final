package Task;


public class Task {
    private final String taskId; // Unique and immutable task ID
    private String name;         // Task name
    private String description;  // Task description

    // Constructor to initialize a Task object with validation
    public Task(String taskId, String name, String description) {
        // Validate task ID: non-null and max 10 characters
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }
        // Validate name: non-null and max 20 characters
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        // Validate description: non-null and max 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getter for task ID (immutable)
    public String getTaskId() {
        return taskId;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name with validation
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        this.name = name;
    }

    // Getter for description
    public String getDescription() {
        return description;
    }

    // Setter for description with validation
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }
        this.description = description;
    }
}
