package Task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks; // In-memory storage for tasks
    private int taskCounter = 1; // Unique ID counter

    // Constructor
    public TaskService() {
        this.tasks = new HashMap<>();
    }

    // Method to add a new task with a unique ID
    public void addTask(String name, String description) {
        String taskId = createTaskId();
        Task newTask = new Task(taskId, name, description);
        tasks.put(taskId, newTask);
    }

    // Method to delete a task by task ID
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        tasks.remove(taskId);
    }

    // Method to update the task name by task ID
    public void updateTaskName(String taskId, String newName) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        tasks.get(taskId).setName(newName);
    }

    // Method to update the task description by task ID
    public void updateDescription(String taskId, String newDescription) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        tasks.get(taskId).setDescription(newDescription);
    }

    // Method to get a task by task ID
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    private String createTaskId() {
        return String.valueOf(taskCounter++);
    }

    //  Method to get all task
    public Map<String, Task> getAllTasks() {
        return new HashMap<>(tasks);
    }
}
