package Contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // Map to store contacts with their unique contact ID as the key
    private final Map<String, Contact> contacts = new HashMap<>();

    // Adds a new contact to the service
    public void addContact(Contact contact) {
        // Check if the contact ID already exists
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("ID already in use.");
        }
        // Add the contact to the map
        contacts.put(contact.getContactId(), contact);
    }

    // Deletes a contact by its unique ID
    public void deleteContact(String contactId) {
        // Check if the contact ID exists in the map
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("ID not found");
        }
        // Remove the contact from the map
        contacts.remove(contactId);
    }

    // Updates an existing contact's fields
    public void updateContact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
        // Retrieve the contact by ID
        Contact contact = contacts.get(contactId);
        // Throw exception if the contact does not exist
        if (contact == null) {
            throw new IllegalArgumentException("ID not found");
        }
        // Update the first name if provided
        if (firstName != null) {
            contact.setFirstName(firstName);
        }
        // Update the last name if provided
        if (lastName != null) {
            contact.setLastName(lastName);
        }
        // Update the phone number if provided
        if (phoneNumber != null) {
            contact.setPhoneNumber(phoneNumber);
        }
        // Update the address if provided
        if (address != null) {
            contact.setAddress(address);
        }
    }

    // Retrieves a contact by its unique ID
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
